import scrapy
import pyshorteners
import pickle
from scrapy.exceptions import CloseSpider
from url_normalize import url_normalize

class QuotesSpider(scrapy.Spider):
    name = "quotes"
    DEPTH_PRIORITY = 1
    SCHEDULER_DISK_QUEUE = 'scrapy.squeues.PickleFifoDiskQueue'
    SCHEDULER_MEMORY_QUEUE = 'scrapy.squeues.FifoMemoryQueue'
    CONCURRENT_REQUESTS_PER_DOMAIN = 10
    custom_urllist = {}
    cust_htmltourl = {}
    page_count = 0
    allowed_domains = ['uic.edu']

    start_urls = [
        'https://www.cs.uic.edu/'
    ]



    def parse(self, response):
        s = pyshorteners.Shortener()
        short_url = s.short(response.url)
        short_url = url_normalize(response.url)
        # short_url = urlparse(short_url)
        if short_url not in self.custom_urllist:
            response_ty = response.headers.get('Content-Type').decode('ASCII')
            if self.page_count < 3000:
                if 'text/html' in response_ty:
                    self.page_count += 1
                    self.custom_urllist[short_url] = self.page_count
                    self.cust_htmltourl[self.page_count] = response.url
                    filename = str(self.page_count)
                    with open('../SimpleChatApp-master/crawledpages/' + filename + '.html', 'wb') as f:
                        f.write(response.body)
                    next_pages = response.css('a::attr(href)').extract()
                    if next_pages is not None:
                        for next_page in next_pages:
                            if next_page not in self.custom_urllist:
                                yield response.follow(next_page, callback=self.parse)
            else:
                self.start_urls.clear()
                pickle.dump(self.cust_htmltourl, open("../SimpleChatApp-master/urlist.p", "wb"))
                raise CloseSpider('3000 pages crawled')
                return



