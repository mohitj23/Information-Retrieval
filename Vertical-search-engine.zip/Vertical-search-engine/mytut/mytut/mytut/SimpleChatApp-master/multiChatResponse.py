from bs4 import BeautifulSoup
import re
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
import os
import math
import operator
import pickle
import pandas
from nltk.corpus import wordnet
import itertools

class multiChatResponse:


    def __init__(self, question):
        self.question = question

    def process_string(self, my_str):
        punctuations = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''
        no_punct = ""
        for char in my_str:
            if char not in punctuations:
                no_punct = no_punct + char
        return no_punct

    def tokenize(self, fileContent):
        punctuations = '!"#$%&\'()*+,./:;<=>?@[\\]^`{|}~'
        no_punctContent = ""
        for char in fileContent:
            if char not in punctuations:
                no_punctContent = no_punctContent + (char.lower())
        return re.split("\s+", no_punctContent.strip())

    def cal_tfidf(self, tfreq, dfre):
        return (tfreq * (math.log2(1400 / dfre)))

    def calculate_weight(self, key, value, s, word_graph):
        sum = 0
        num = word_graph[value][key]
        for c_node in word_graph[value]:
            sum = sum + word_graph[value][c_node]
        if sum == 0:
            return 0
        else:
            return num / sum

    def add_txt(self, txd):
        lk = []
        ps1 = PorterStemmer()
        stopset = set(stopwords.words('english'))
        for w in txd.split():
            if w and w not in stopset:
                word = ps1.stem(w)
                if word not in stopset and len(word) > 2 and word != '':
                    synonyms = []
                    for syn in wordnet.synsets(word):
                        for l in syn.lemmas():
                            synonyms.append(l.name())
                    a = set(synonyms)
                    for i, val in enumerate(itertools.islice(a, 2)):
                        lk.append(val)
        st = ' '.join(lk)
        txa = txd + st
        return txa



    def scorecal_helper(self, word_graph, v, s):
        current_val = 0
        number_of_nodes = len(word_graph)
        alpha = 0.85
        pi_alpha = (1 / number_of_nodes) * (1 - alpha)
        if len(word_graph[v]) > 0:
            for val in word_graph[v]:
                current_val = current_val + (self.calculate_weight(v, val, s, word_graph) * s[val])
            score = alpha * current_val + pi_alpha
            return score
        else:
            return pi_alpha


    def doc_indexbuilder(self):
        ps = PorterStemmer()
        stopset = set(stopwords.words('english'))
        word_graphs = []
        doc_q = {}
        vocabulary = {}
        doc_max = {}
        j = 1
        file_path = 'crawledpages/'
        for file in sorted(os.listdir(file_path)):
            max = 0
            list_words = []
            words = {}
            with open(file_path + file, 'r', encoding='cp850') as x:
                filecontents = x.read()
                soup = BeautifulSoup(filecontents, 'html.parser')
                for script in soup(["script", "style"]):
                    script.decompose()
                just_text = soup.get_text()
                lines = (line.strip() for line in just_text.splitlines())
                # break multi-headlines into a line each
                chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
                # drop blank lines
                just_text = '\n'.join(chunk for chunk in chunks if chunk)
                just_text = self.process_string(just_text)
                w_index = 0
                last_word = None
                last_vwordindex = None
                for w in just_text.split():
                    if w and w not in stopset:
                        word = ps.stem(w)
                        if word not in stopset and len(word) > 2 and word != '':
                            list_words.append(word)
                            s = str(file)
                            if word in vocabulary:
                                if s in vocabulary[word]:
                                    vocabulary[word][s] = vocabulary[word][s] + 1
                                else:
                                    vocabulary[word][s] = 1
                            else:
                                vocabulary[word] = {}
                                vocabulary[word][s] = 1
                            if vocabulary[word][s] > max:
                                max = vocabulary[word][s]
                            if len(words):
                                if word in words:
                                    if w_index - 1 == last_vwordindex:
                                        if last_word in words[word]:
                                            words[word][last_word] += 1
                                        else:
                                            words[word][last_word] = 1
                                        if word in words[last_word]:
                                            words[last_word][word] += 1
                                        else:
                                            words[last_word][word] = 1
                                    last_vwordindex = w_index
                                    last_word = word
                                else:
                                    words[word] = {}
                                    if w_index - 1 == last_vwordindex:
                                        words[word] = {last_word: 1}
                                        words[last_word][word] = 1
                                    last_vwordindex = w_index
                                    last_word = word
                            else:
                                words[word] = {}
                                last_word = word
                                last_vwordindex = w_index
                    w_index += 1
            word_graphs.append(words)
            doc_max[file] = max
            doc_q[file] = set(list_words)
            j += 1


        score_graphs = []
        for g in word_graphs:
            s = {}
            for v in g:
                s[v] = 1 / len(g)
            psa = {}
            c = 0
            for x in range(10):
                for v in g:
                    sca = self.scorecal_helper(g, v, s)
                    # s[v] = sca
                    if v in psa and psa[v] == sca:
                        c += 1
                    psa[v] = sca
                s.clear()
                s.update(psa)
                if c == len(g):
                    break
                else:
                    c = 0
            score_graphs.append(s)

        doc_tfidf = {}
        for doc in doc_q:
            d = str(doc)
            mag = 0
            for term in doc_q[doc]:
                mag += self.cal_tfidf((vocabulary[term][d] / doc_max[doc]), len(vocabulary[term])) ** 2
            doc_tfidf[d] = math.sqrt(mag)

        pickle.dump(doc_tfidf, open("doctfidf.p", "wb"))
        pickle.dump(doc_q, open("docq.p", "wb"))
        pickle.dump(vocabulary, open("voc.p", "wb"))
        pickle.dump(doc_max, open("docm.p", "wb"))
        pickle.dump(score_graphs, open("sg.p", "wb"))


    def query_resultbuilder(self):
        ps = PorterStemmer()
        stopset = set(stopwords.words('english'))
        doc_tfidf = pickle.load(open("doctfidf.p", "rb"))
        doc_q = pickle.load(open("docq.p", "rb"))
        vocabulary = pickle.load(open("voc.p", "rb"))
        doc_max = pickle.load(open("docm.p", "rb"))
        score_graphs = pickle.load(open("sg.p", "rb"))
        query_list = [self.question]

        pg_scores = []
        g_names = []
        g_index = 1
        for g in score_graphs:
            ttl_score = 0
            for line in query_list:
                pr_line = self.process_string(line)
                pr_line = self.add_txt(pr_line)
                for word in pr_line.split():
                    if word not in stopset and word:
                        word1 = ps.stem(word)
                        if word1 not in stopset and len(word1) > 2 and word1 != '':
                            if word1 in g:
                                ttl_score += g[word1]
            pg_scores.append(ttl_score)
            g_names.append(str(g_index)+'.html')
            g_index += 1

        df = pandas.DataFrame.from_dict({'hml':g_names, 'pgscores': pg_scores})

        j = 1
        query_terms = {}
        for line in query_list:
            dict1 = {}
            pr_line = self.process_string(line)
            pr_line = self.add_txt(pr_line)
            for word in pr_line.split():
                if word not in stopset and word:
                    word1 = ps.stem(word)
                    if word1 not in stopset and len(word1) > 2 and word1 != '':
                        if word1 in vocabulary:
                            if word1 in dict1:
                                dict1[word1] += 1
                            else:
                                dict1[word1] = 1
            query_terms[j] = dict1
            j += 1

        query_magnitudes = []
        for i in query_terms:
            mag = 0
            for key in query_terms[i]:
                if key in vocabulary:
                    mag += (self.cal_tfidf(query_terms[i][key], len(vocabulary[key]))) ** 2
            query_magnitudes.append(mag ** (0.5))

        lofd = []
        i = 0
        for line in query_list:
            dict1 = {}
            pr_line = self.process_string(line)
            pr_line = self.add_txt(pr_line)
            for word in pr_line.split():
                if word not in stopset and word:
                    word1 = ps.stem(word)
                    if word1 not in stopset and len(word1) > 2 and word1 != '':
                        if word1 in vocabulary:
                            for d in vocabulary[word1]:
                                tf_idf = 0
                                tf_idf = self.cal_tfidf(vocabulary[word1][d] / doc_max[d],
                                                   len(vocabulary[word1])) * self.cal_tfidf(1, len(vocabulary[word1]))
                                tf_idf = tf_idf / (doc_tfidf[d] * query_magnitudes[i])
                                if d in dict1:
                                    dict1[d] = dict1[d] + tf_idf
                                else:
                                    dict1[d] = tf_idf

            lofd.append(dict1)
            i += 1

        sorted_lofd = []
        sorted_lofd.append(sorted(lofd[0].items(), key=operator.itemgetter(1), reverse=True))

        lk = [[*x] for x in zip(*sorted_lofd[0])]
        dfToList = []
        if len(lk) > 0:
            tfidf_scores = lk[1]
            g1_names = lk[0]
            df1 = pandas.DataFrame.from_dict({'hml':g1_names, 'tfidfscores': tfidf_scores})
            df2 = pandas.merge(df, df1, on=['hml'], how = 'inner')
            df2.sort_values(['tfidfscores', 'pgscores'], ascending=False, inplace = True)
            df2.to_csv("pg_rank.csv")
            dfToList = df2['hml'].tolist()
        return dfToList
